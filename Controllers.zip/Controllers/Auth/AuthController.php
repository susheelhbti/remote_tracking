<?php
 
namespace App\Http\Controllers\Auth;
use App\User;
use App\Membership;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

use Mail;
use App\Http\Controllers\GoogleAuthCtrl;

use App\Http\Controllers\Paymentcls;



use App\Exchange_g2f;

use Illuminate\Support\Facades\DB;


class AuthController extends Controller
{
     public function __construct(Request $request) {
        
  // $this->middleware('auth');
        $this->request = $request;
    }  
    
    
    
    public function login(Request $request) {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
            //'remember_me' => 'boolean'
        ]);
        $credentials = request(['email', 'password']);
        
        
        if(!Auth::attempt($credentials))
         {  
          return response()->json([
                'message' => 'Login failure!!!',
                "Error" =>   true
            ], 401);
         }
            
            
               $data = Exchange_g2f::where('email',  '=' ,$this->request->email)->get();
            
              
             if(count($data)==1)
             
             { 
                 return response()->json([
            'email' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
            'expires_at' => Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString(),
            'user'=> $user
            
        ]);
                 
             }
            
        $user = $request->user();
        
        
        $tokenResult = $user->createToken('Personal Access Token');
        $token = $tokenResult->token;
        if ($request->remember_me)
            $token->expires_at = Carbon::now()->addWeeks(1);
        $token->save();
        
        
        return response()->json([
            'access_token' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
            'expires_at' => Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString(),
            'user'=> $user,
            'message' => 'Login Success!!!',
                "Error" =>   false
            
        ]);
    }
    
    
    
    public function googleauthtest(Request $request) {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
            //'remember_me' => 'boolean'
        ]);
        $credentials = request(['email', 'password']);
        
        
        if(!Auth::attempt($credentials))
           
           
           return response()->json([
                'message' => 'Login failure!!!',
                "Error" =>   true
            ]);
            
            
 $data = Exchange_g2f::where('email',  '=' ,$this->request->email)->get();
            
              
             if(count($data)==1)
             
             { 
                 return response()->json([
            'error' => false,
            'gauth' => true,
            'otp' => true,
            'user' => $request->user()
            
          ]);
                 
             }
             else
             {
                
                   $user = Auth::user();
        
        
        $tokenResult = $user->createToken('Personal Access Token');
        $token = $tokenResult->token;
         $token->expires_at = Carbon::now()->addWeeks(1);
        $token->save();
        
        
        return response()->json([
            'access_token' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
               'gauth' => false,
            'expires_at' => Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString(),
            'user'=> $user
            
        ]);
        
        
             }
        
       
    }
    
    
    public function googleauthverify(Request $request) {
     
     
     
      
         $data = Exchange_g2f::where('email',  '=' ,$this->request->email)->get();
            
    
 
 
 

if (!$checkResult) {
    
    $credentials = request([$this->request->email,$this->request->password]);
        
        
        if(!Auth::attempt($credentials))
        {
             return response()->json([
                'message' => 'Login failure!!!',
                "Error" =>   true
            ]);
            
        }
            else
            {
                
             $user = Auth::user();
        
        
        $tokenResult = $user->createToken('Personal Access Token');
        $token = $tokenResult->token;
         $token->expires_at = Carbon::now()->addWeeks(1);
        $token->save();
        
        
        return response()->json([
            'access_token' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
            'expires_at' => Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString(),
            'user'=> $user
            
        ]);
    } 
           
           
           
}

        
    



else
{
    return response()->json([
                'message' => 'Wrong Google Auth Code',
                'Error' => true
            ]); 
    
    
}

}
 
      
    
    
  public function register(Request $request)
    {
        $request->validate([ 
            'email' => 'required|string|email|unique:users',
            'password' => 'required|string'
        ]);
        $ar=array();
        $user = new User;
         $user->first_name =$request->name;
       
        $user->email = $request->email;
        $user->password = bcrypt($request->password);

 
        
         $data = array('name'=>$request->name,'message1'=>$request->name  .'  Please verify your email and then login');
         $GLOBALS['email']=$request->email;
         $GLOBALS['name']=$request->name;
   
      Mail::send('mail', $data, function($message) {
         $message->to($GLOBALS['email'], $GLOBALS['name'])->subject
            ('Please verify your email and then login');
         $message->from('support@aistore2030.com','Verify Email');
         
      });
             $user->save();
     // echo "Basic Email Sent. Check your inbox and Email Sent with attachment. Check your inbox.";
    
        $ar['message']="Successfully created user!.";
      
         $ar['Error']=false;
         return response()->json($ar);
       
    }
    
    
    
    public function logout(Request $request)
    {
        $request->user()->token()->revoke();
        return response()->json([
            'message' => 'Successfully logged out'
        ]);
    }
  
    /**
     * Get the authenticated User
     *
     * @return [json] user object
     */
    public function getbalance(Request $request)
    {
              $user = Auth::user();
              
              
              
    $ar=array();
             
    $ar['Error']=false; 
    
  
    
       $ar['result']=$user->only(['id' ,'INR' , 'USD' , 'BTC' , 'LTC' 
        
        ]); 
        
        
        return response()->json($ar);
        
        
    }
    
      public function user(Request $request)
    {
              
                $user = Auth::user();
        return response()->json($user->only(['id','email',  'first_name', 'last_name', 'address1', 'address2','state', 'country', 'mobile',
        'district', 'street', 'apartment_number', 'zip_code','house_no', 'city',  'dob', 'gender','profile_pic','balance','status','membership','plan','callbackurl','notification_fund_status','notification_url','bank_name','account_type','account_no','branch','ifsc_code','INR']
        ));
        
        
    }
    
    public function get_client_ip() {
     
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    $handle = curl_init();
    $url="https://www.aistore2030.com/ip.php?ip=$ipaddress";
    // Set the url
    curl_setopt($handle, CURLOPT_URL, $url);
    // Set the result output to be a string.
    curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);

    $output = curl_exec($handle);

    curl_close($handle);
   $ar=array();
    //echo $output;
   // var_dump($url);
   
         $user = Auth::user();
        $user->country ="India";
         $user->save();
   $ar['country']= $output;
   
     $ar['status']="success";
      return response()->json($ar);
      
}

    
    
    public function user2(Request $request)
    {
        
               $user = Auth::user();
               
               
               
               $ar=array();
               $ar['status']="success";
               
               
               $ar['result']=$user->only([  'id', 'email','mobile',     'first_name', 'last_name', 'address1', 'address2', 'state', 'country', 'mobile', 'district', 'street', 'apartment_number', 'zip_code', 'house_no', 'city', 'images', 'dob', 'gender',  'national_id_card', 'drivers_licence', 'callbackurl',  'account_status', 'membership','notification_fund_status' ]);
               
               
               
               
        return response()->json($ar);
 

        
    }
    
    
    
     public function changepassword(Request $request)
    {
      
      
      $ar=array();
      
        $ar['Error']=true;
      

        if(strcmp($request->get('current-password'), $request->get('new-password')) == 0){
            
            
            
              $ar['message']="New Password cannot be same as your current password. Please choose a different password.";
        }


        //Change Password
        $user = Auth::user();
        $user->password = bcrypt($request->get('new-password'));
        $user->save();
        
          $ar['message']="Successfully updated the password.";
              
              
             $ar['Error']=false;
             
 return response()->json($ar);
 
 
    }
    
    
        public function changeStatus(Request $request)

    {

        $user = User::find($this->request['id']);

        $user->status =  $user->status==1?0:1;
    

        $user->save();

  

        return response()->json(['success'=>'Status change successfully.']);

    }
    
    
        public function accountStatus(Request $request)

    {
    $ar=array();
        $user = User::find($this->request['id']);

        $user->account_status =  $user->account_status==1?0:1;
    

        $user->save();

   $ar['message']="Account Status change successfully.";
              
              
     $ar['Error']=false;

        return response()->json($ar);

    }
    
    
    
        public function notificationfundStatus(Request $request)

    {
    $ar=array();
    
       $user = Auth::user();
        //$user = User::find($this->request['id']);

        $user->notification_fund_status =  $user->notification_fund_status==1?0:1;
    
   
        $user->save();

   $ar['message']="Notification Fund Status change successfully.";
              
              
     $ar['Error']=false;

        return response()->json($ar);

    }
    
    
        public function deleteaccount(Request $request)

    {
         $ar=array();
        $user = User::find($this->request['id']);

       $user->delete();


        $ar['message']="Account Deleted successfully.";
              
              
        $ar['Error']=false;

        return response()->json($ar);

    }
    
     public function deleteplan(Request $request)

    {
         $ar=array();
        $user = Membership::find($this->request['id']);

       $user->delete();


        $ar['message']=" Deleted successfully.";
              
              
        $ar['Error']=false;

        return response()->json($ar);

    }
    
              
 public function postupdatemembership()
    {
        $m = Membership::find( $this->request['membership']);
      
     
        $ar=array();
  
       $user = Auth::user();
  
      if(  $user->membership   == $this->request['membership'])
      {
             $ar['message']="You already have this membership plan activated";
              
              
             $ar['Error']=true;
           
     
          
 return response()->json($ar);
          exit();
      }
       
  $sc=new    Paymentcls();
  
  
  
       
       
  $amount=$m->price;
   $error=$sc->debit_user( $user,$amount , "USD","Membership purchase");
       
       
       if(!$error)
       {
        $user->membership   = $this->request['membership'];
                   
         $user->plan=        $m->plan;
                   
                   
            $user->save();
 


       $ar['message']="Successfully updated the membership.";
              
              
             $ar['Error']=false;
       }
       else
       {
            $ar['message']="Please deposit payment to complete this order";
              
              
             $ar['Error']=true;
           
       }
          
 return response()->json($ar);
 
  
    }
    
    
 public function postprofile()
    {
        
        $ar=array();
  
        $ar['Error']=true;
 
         $user = Auth::user();
        $user->email_verified_at = $this->request['email_verified_at'];
       $user->first_name =  $this->request['first_name'];
           $user->last_name =  $this->request['last_name'];
             $user->email =  $this->request['email'];
            $user->address1 =    $this->request['address1'];
              $user->address2 =  $this->request['address2'];
                $user->state =  $this->request['state'];
                  $user->country =  $this->request['country'];
                  $user->city  = $this->request['city'];
                   $user->callbackurl  = $this->request['callbackurl'];
                     $user->street = $this->request['street'];
                      $user->district = $this->request['district'];
                      $user->apartment_number = $this->request['apartment_number'];
                      $user->zip_code = $this->request['zip_code'];
                       $user->house_no  = $this->request['house_no'];
                       $user->gender  = $this->request['gender'];
                       $user->dob  = $this->request['dob'];
                     $user->mobile  = $this->request['mobile'];
                       $user->notification_url = $this->request['notification_url'];
                       $user->profile_pic = $this->request['profile_pic'];
                        $user->bank_name = $this->request['bank_name'];
                        $user->account_type = $this->request['account_type'];
                         $user->account_no = $this->request['account_no'];
                          $user->branch = $this->request['branch'];
                 $user->ifsc_code = $this->request['ifsc_code'];
                 
                        
            $user->save();
   
 

       $ar['message']="Successfully updated the profile.";
              
              
             $ar['Error']=false;
             
 return response()->json($ar);
    }
    
    
    public function postkycnew(Request $request)
{
    
    $ar=array();
        $ar['Error']=true;
           $user = Auth::user();
       

 $a=$request->document_type;
 $user->$a=$request->document;
 
    $user->save();
    
       $ar['message']="Successfully updated the profile.";
      
         $ar['Error']=false;
             
 return response()->json($ar);
    
 

}
    
    
    
    
    
       public function  getplan(Request $request)

    {
         
        
        
         $ar=array();
         
         
        $m = Membership::find($this->request['id']);

        
        
          $rt=file_get_contents("https://api-pub.bitfinex.com/v2/ticker/tBTCUSD");

$r=json_decode( $rt) ;
 
 
$rate=$r[0];
 
$amount_btc = $m->price / $rate;


  $m->amount_btc=$amount_btc;
  

 
              $n=new Paymentcls();
              
        $m['BtcAddress']= $n->getBtcAddress( );
        
        
        $ar['Error']=false;
        $ar['result']= $m;

        return response()->json($ar);

    } 
    
    
    
}