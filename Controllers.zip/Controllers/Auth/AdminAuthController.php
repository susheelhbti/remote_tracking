<?php
 
namespace App\Http\Controllers\Auth;
use App\User;
use App\Membership;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;


use App\Http\Controllers\GoogleAuthCtrl;

use App\Http\Controllers\Paymentcls;



use App\Exchange_g2f;

use Illuminate\Support\Facades\DB;


class AdminAuthController extends Controller
{
     public function __construct(Request $request) {
        
  // $this->middleware('auth');
        $this->request = $request;
    }  
     
     
           public function changelogin(Request $request)

    {
        if(Auth::user()->roll<>10)
        {
   $request->user()->token()->revoke();
   
   
        return response()->json([
            'message' => 'Successfully logged out'
        ]);
        }
        
        $user = User::find($this->request['id']);



        $tokenResult = $user->createToken('Personal Access Token');
        $token = $tokenResult->token;
         $token->expires_at = Carbon::now()->addWeeks(1);
        $token->save();
        
        
        return response()->json([
            'access_token' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
            'expires_at' => Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString(),
            'user'=> $user,
            'message' => 'Login Success!!!',
                "Error" =>   false
            
        ]);
        
        
        

    }
    
    
    
}