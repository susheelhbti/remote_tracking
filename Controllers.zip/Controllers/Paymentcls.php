<?php


namespace App\Http\Controllers;

 
use App\Page;
use App;
use View;
use MetaTag; 

use App\ChargeCommision;
use App\Income;
use App\MemberExtra;
use App\Deposit;
use App\Gateway;
use App\Lib\GoogleAuthenticator;
use App\Transaction;
use App\User;
use Config;
use App\Coins;

use App\Exchange_deposit;

use App\System_Settings;

use App\Exchange_widthdraw;
use App\Exchange_bookings;
use Illuminate\Support\Facades\DB;

 
use App\Http\Controllers\Controller;


use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Intervention\Image\Facades\Image;


use App\Notifications\Login;


class Paymentcls extends Controller
{ 

    public function __construct( )
    {
         
    
            
            
    }
 
  

public function  credit_user( $user,$amount ,$coin,$description)
{ $error=true;

   

   $old_balance= $user->$coin  ;
    
    $new_balance=  (double)$old_balance+(double)$amount;
    
    
     
    
  $trid = DB::table('system_transactions')->insertGetId(
    [ 'user_id' => $user->id ,'coin' => $coin  ,'type' =>  'credit' ,'amount' => $amount  ,'balance' => $new_balance  ,'status' =>"Success" ,'description' =>$description   ]
);


$user->$coin =$new_balance;

$user->save();
  
$error=false;
 
 return $error;
    
    
}


public function debit_user( $user,$amount,$coin,$description )
{ 
    
    $error=true;
     $old_balance= $user->$coin;
     
    $new_balance=   (double)$old_balance- (double)$amount;
    
     
    if(   (double) $new_balance > 0)
    {
 $trid = DB::table('system_transactions')->insertGetId(
    [ 'user_id' => $user->id ,'coin' => $coin  ,'type' =>  'debit' ,'amount' => $amount  ,'balance' => $new_balance  ,'status' =>"Success" ,'description' => $description  ]
);


$user->$coin=$new_balance;

$user->save();
$error=false;
}
else
{
       $error=true;
}
 

 
 return $error;
    
    
}
function getBtcAddress( )
{
    
 
 $user_id= Auth::user()->id;
    
     
    $deposit_address = DB::table('deposit_address')->where('user_id', $user_id)->count();
    
    
   
   if( $deposit_address==0)
   {
 
 
        $this->setBtcAddress($user_id );
   
   }
  
   $data=   DB::table('deposit_address')->where('user_id', $user_id)->where('coin', "Bitcoin")->get()->first(); 
  
  return $data->address ;	
}

function setBtcAddress($user_id )
{
     
 
 $secret = 'ZzsMLGZzsMLGKe162CfA5EcG6jKe162CfA5EcG6j';

$my_xpub = $this->getXpub( );
 
 
$my_api_key = '36276ce3-16c5-471d-bcfd-ac143bfeccd2';


$invoice=date("MdYhisA").$user_id;

$hit_url=$_SERVER['HTTP_HOST'] ."/". $_SERVER['REQUEST_URI'];




$my_callback_url ="https://". $_SERVER['HTTP_HOST'] ."/system/btcdeposit?invoice_id=".$invoice."&user_id=".$user_id."&secret=".$secret;
 

$root_url = 'https://api.blockchain.info/v2/receive';

$parameters = 'xpub=' .$my_xpub. '&callback=' .urlencode($my_callback_url). '&key=' .$my_api_key;

 
 $call=$root_url . '?' . $parameters;
 
 
$response = file_get_contents( $call);
 //var_dump( $call);
$object = json_decode($response);


DB::table('deposit_address')->insert(['coin'=>"Bitcoin", 'user_id' => $user_id, 'address' => $object->address,'url_hit' => $call ,'url_res' =>$response ]);

 
 DB::table('exchange_btcaddress')->insert(['xpub'=>$my_xpub , 'user_id' => $user_id, 'address' => $object->address ]);

 
 
     
  return $object->address ;		    


}

  
   
 function getXpub( )
  {


 
 
  $qr="select xpub ,n from (SELECT count(address) n, xpub FROM `exchange_btcaddress` GROUP by xpub ) t WHERE n < 12 order by n desc limit 1 ";
 
 
   $xp = DB::select($qr) ;
  return  $xp[0]->xpub;


   }         
            
}