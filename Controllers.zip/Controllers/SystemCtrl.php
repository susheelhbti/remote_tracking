<?php


namespace App\Http\Controllers;

 
use App\Page;
use App;
use View;
use MetaTag; 

use App\ChargeCommision;
use App\Income;
use App\MemberExtra;
use App\Deposit;
use App\Gateway;
use App\Lib\GoogleAuthenticator;
use App\Transaction;
use App\User;
use Config;
use App\Coins;
use Mail;

use App\Exchange_deposit;

use App\System_Settings;

use App\Exchange_widthdraw;
use App\Exchange_bookings;
use Illuminate\Support\Facades\DB;

 
use App\Http\Controllers\Controller;


use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Intervention\Image\Facades\Image;


use App\Notifications\Login;


class SystemCtrl extends Controller
{
    private $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
        
    
            
            
    }
 
 
 
public function getlogo()
{  

      $ss  =System_Settings::first();
      
  return response()->json($ss );
    
}   

public function sendemail()
{  

    //   $data = array('name'=>"Virat Gandhi");
      
     
      $data = array('name'=>"Virat Gandhi");
      Mail::send('mail', $data, function($message) {
         $message->to('noureenahsan91@gmail.com', 'Tutorials Point')->subject
            ('Laravel HTML Testing Mail');
         $message->from('noureenahsan91@gmail.com','Virat Gandhi');
      });
      echo "HTML Email Sent. Check your inbox.";
   
   
    //   Mail::send(['text'=>'mail'], $data, function($message) {
    //      $message->to('noureenahsan91@gmail.com', 'Tutorials Point')->subject
    //         ('Laravel Basic Testing Mail');
    //      $message->from('noureenahsan91@gmail.com','Noureen Ahsan');
         
    //   });
    //   echo "Basic Email Sent. Check your inbox and Email Sent with attachment. Check your inbox.";
    
} 


  public function postlogo(Request $request)
{
    $user = Auth::user();
       $ar=array();
        $user1=$user->id;
    if($user1< 9 )
    {
       
        $ar['Error']=false;
       $ar['message']="Unable to upload";   
        
 return response()->json($ar);
    exit();
    }
    
    
    
        $ar['Error']=true;
         
    $ss  = System_Settings::first();
    
    
    
 $ss->logo=$request->document;
 
    $ss->save();
    
    $ar['Settings']=$ss;
       $ar['message']="Successfully updated  ";
      
         $ar['Error']=false;
             
 return response()->json($ar);
    
 

}
    
    
    
    
function getBtcAddress( )
{
    
 
 $user_id= Auth::user()->id;
    
     
    $deposit_address = DB::table('deposit_address')->where('user_id', $user_id)->count();
    
    
   
   if( $deposit_address==0)
   {
 
 
        $this->setBtcAddress($user_id );
   
   }
  
   $data=   DB::table('deposit_address')->where('user_id', $user_id)->where('coin', "Bitcoin")->get()->first(); 
  
  return $data->address ;	
}

function setBtcAddress($user_id )
{
     
 
 $secret = 'ZzsMLGZzsMLGKe162CfA5EcG6jKe162CfA5EcG6j';

$my_xpub = $this->getXpub( );
 
 
$my_api_key = '36276ce3-16c5-471d-bcfd-ac143bfeccd2';


$invoice=date("MdYhisA").$user_id;

$hit_url=$_SERVER['HTTP_HOST'] ."/". $_SERVER['REQUEST_URI'];




$my_callback_url ="https://". $_SERVER['HTTP_HOST'] ."/system/btcdeposit?invoice_id=".$invoice."&user_id=".$user_id."&secret=".$secret;
 

$root_url = 'https://api.blockchain.info/v2/receive';

$parameters = 'xpub=' .$my_xpub. '&callback=' .urlencode($my_callback_url). '&key=' .$my_api_key;

 
 $call=$root_url . '?' . $parameters;
 
 
$response = file_get_contents( $call);
 //var_dump( $call);
$object = json_decode($response);


DB::table('deposit_address')->insert(['coin'=>"Bitcoin", 'user_id' => $user_id, 'address' => $object->address,'url_hit' => $call ,'url_res' =>$response ]);

 
 DB::table('exchange_btcaddress')->insert(['xpub'=>$my_xpub , 'user_id' => $user_id, 'address' => $object->address ]);

 
 
     
  return $object->address ;		    


}

          
    
          public function LedgetTransactionsdeposits()
{ 
    
    $user_id= Auth::user()->id;
 $data=DB::table('system_transactions')->where('user_id',$user_id)->where('type', 'credit')->orderBy('id', 'desc')->take(50)->get()  ;
      
  return response()->json($data );
    
}    




       public function LedgetTransactionswidthdraws()
{ 
    
    $user_id= Auth::user()->id;


 $data=DB::table('system_transactions')->where('user_id',$user_id)->where('type', 'debit')->orderBy('id', 'desc')->take(50)->get()  ;
      
      ;
      
  return response()->json($data );
    
}    
   
   
 function getXpub( )
  {


 
 
  $qr="select xpub ,n from (SELECT count(address) n, xpub FROM `exchange_btcaddress` GROUP by xpub ) t WHERE n < 12 order by n desc limit 1 ";
 
 
   $xp = DB::select($qr) ;
  return  $xp[0]->xpub;


   }
           
         public function LedgetTransactions()
{ 
    
    $user_id= Auth::user()->id;
 $data=DB::table('system_transactions')->where('user_id',$user_id)->orderBy('id', 'desc')->take(50)->get()  ;
      
  return response()->json($data );
    
}


 


         public function LedgetUsers()
{ 
    
    //$user_id= Auth::user()->id;
 $data=DB::table('users')->orderBy('id', 'desc')->take(50)->get()  ;
      
  return response()->json($data );
    
}

    public function KYCUsers()
{ 
    
 //$user_id= Auth::user()->id;
 $data=DB::table('users')->where('status',1)->orderBy('id', 'desc')->get()  ;
  return response()->json($data );
    
}



    public function NonKYCUsers()
{ 
    
 //$user_id= Auth::user()->id;
 $data=DB::table('users')->where('status',0)->orderBy('id', 'desc')->get()  ;
  return response()->json($data );
    
}







    public function DeleteUsersAccountRequest()
{ 
    
 //$user_id= Auth::user()->id;
 $data=DB::table('users')->where('account_status',1)->orderBy('id', 'desc')->get()  ;
  return response()->json($data );
    
}

         public function Ledgetmembership()
{ 
    
    //$user_id= Auth::user()->id;
 $data=DB::table('membership')->orderBy('id', 'asc')->get()  ;
      
  return response()->json($data );
    
}


public function postdeposits(Request $r)
{
 
   $deposit=   "";
       $user_id= Auth::user()->id;
     
    
    
     $deposit=  $this->getBtcAddress( );
   
    $id = DB::table('exchange_deposit')->insertGetId(
    [ 'user_id' => $user_id ,'coin' => $r->coin ,'deposit_address' => $deposit ,'amount' => $r->amount ]
);
 
  
 
   
  $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Request submitted successfully";
    
    return response()->json($ar);
    
   
} 

public function receive_payment(Request $r)
{
 $ar=array();
 
 
   $deposit=   "";
       $user_id= Auth::user()->id;
     
     
    if($r->coin=="BTC")
    {
    $deposit=  $this->getBtcAddress( );
   
    $ar['address']= $deposit;
    $ar['coin']="Bitcoin";
    
   $ar['min_deposit']="<b>Minimum Deposit</b> 0.02 BTC (OR 500 USD Which is lower) otherwise it will be ignore with no refund.";
   
    }
    else if($r->coin=="USD")
    {
          $ar['address']=  "sales@aistore2030.com";
    $ar['coin']="USD Deposit by PAYPAL";
     $ar['method']="PAYPAL";
             $ar['min_deposit']="<b>Minimum Deposit</b> 500 USD otherwise it will be ignore with no refund"; 
  
    }
   
     else  
    {
          $ar['address']=  "aistore2030@sbi";
    $ar['coin']="INR";
     
     
       $ar['method']="UPI";
       
        
       
       
      $ar['min_deposit']="<b>Minimum Deposit</b> 10,000 INR otherwise it will be ignore with no refund";   
    }
   
   
   
   $r=array();
   $r['status']=200;
   $r['result']=$ar;
  
    return response()->json($r);
  
   
} 

 

 
 



public function send_payment()
{ 
       $user = Auth::user();
    
    $user_id=$user->id;
  
    
      $trid = DB::table('system_transactions')->insertGetId(
    [ 'user_id' => $user_id ,'coin' => $this->request['coin']  ,'cr' => 0 ,'dr' =>  $this->request['amount_coin']  ,'status' =>"Success" ,'description' =>"Widthdraw Request ". $this->request['to']   ]
);

     
            
     $id = DB::table('exchange_widthdraw')->insertGetId(
    [ 'user_id' => $user_id ,'coin' => $this->request['coin'] ,'amount' => $this->request['amount_coin'],'widthdraw_address' =>  $this->request['to'] ]
);

 



    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Request submitted successfully";
    
    return response()->json($ar);
    
    
    
    
}



public function add_plan()
{ 
       $user = Auth::user();
    
    $user_id=$user->id;
  
    
      $trid = DB::table('membership')->insertGetId(
    [ 'user_id' => $user_id ,'plan' => $this->request['name'] ,
    'row1' =>  $this->request['row1'] ,
    'row2' =>  $this->request['row2'] ,
    'row3' =>  $this->request['row3'] ,
    'row4' =>  $this->request['row4'],
        'row5' =>  $this->request['row5'],
            'row6' =>  $this->request['row6'],
                'row7' =>  $this->request['row7'],
    'price' =>  $this->request['price']]
);

  


    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Plan submitted successfully";
    
    return response()->json($ar);
    
    
    
    
}


 public function create_chat()
{ 
       $user = Auth::user();
    
    $user_id=$user->id;
   $user_name=$user->first_name;
    
      $trid = DB::table('chat')->insertGetId(
    ['user_id' => $user_id ,'user_name' => $user_name,
    'message' => $this->request['message']
    ]
);

  


    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Message send successfully";
    
    return response()->json($ar);
 
    
}

 public function getchat()
{ 
    
    $user_id= Auth::user()->id;
 $data=DB::table('chat')->orderBy('id', 'asc')->get()  ;
      
  return response()->json($data );
    
}


public function addmessage()
{
 
   
    $id = DB::table('email_messages')->insertGetId(
    [ 'messages' => $this->request['messages'] 
    ,'message_type' => $this->request['message_type']]
);
 
  
 
   
  $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Message submitted successfully";
    
    return response()->json($ar);
    
   
} 

 public function message()
{ 
    
    $user_id= Auth::user()->id;
 $data=DB::table('email_messages')->orderBy('id', 'asc')->get()  ;
      
  return response()->json($data );
    
}
public function addmessage_dispute()
{
  
    $user_id= Auth::user()->id;
   
    $id = DB::table('dispute')->insertGetId(
    [ 'message' => $this->request['message'] 
    ,'user_id' =>$user_id ]
);
 
  
 
   
  $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Message submitted successfully";
    
    return response()->json($ar);
    
   
} 

 public function message_dispute()
{ 
    
    $user_id= Auth::user()->id;
 $data=DB::table('dispute')->orderBy('id', 'asc')->get()  ;
      
  return response()->json($data );
    
}

          
}