<?php


namespace App\Http\Controllers;

 
use App\Page;
use App;
use View;
use MetaTag; 

use App\ChargeCommision;
use App\Income;
use App\MemberExtra;
use App\Deposit;
use App\Gateway;
use App\Lib\GoogleAuthenticator;
use App\Transaction;
use App\User;
use Config;
use App\Coins;
use Mail;

use App\Exchange_deposit;

use App\System_Settings;

use App\Employee; 
use Illuminate\Support\Facades\DB;

 
use App\Http\Controllers\Controller;


use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Intervention\Image\Facades\Image;


use App\Notifications\Login;

 
class PaymentCtrl extends Controller
{
    private $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
        
    
            
            
    }
  

public function dispute_payment(Request $request)
{ 
    
    $ar=array();
      
      
       $user = Auth::user();
    
    $user_id=$user->id;
  $user_email=$user->email;
     
      
  $data=DB::table('safe_payment')->where('user_id',$user->id)->where('status',"Pending")->where('id',$request->id)->first()  ;
  
 $recipient_user_email= $data->recipient_user_email;
  $recipient_user_amount= $data->amount;
   $recipient_user_currency= $data->coin;
    $recipient_user_description= $data->description;
 $recipient_user =User::where('email',$recipient_user_email)->first() ;

 $GLOBALS['email']=$recipient_user_email;
  if( $recipient_user <> null)
  {
      
       
      
$affected = DB::table('safe_payment')
              ->where('user_id',  $user_id)
              ->where('id', $request->id) 
              ->update(['status' => "Dispute"]);
              
              
              $data = array('name'=>$user_email,'message1'=>'Payment Dispute to ' .$recipient_user_email,'amount1'=>$recipient_user_amount,'currency'=>$recipient_user_currency,'description'=>$recipient_user_description);
         
              $GLOBALS['email']= $recipient_user_email;
        $GLOBALS['user_email']=$user_email;
   
      Mail::send('mail1', $data, function($message) {
         $message->to($GLOBALS['user_email'], 'Payment Disputed')->subject
            ('Payment Disputed');
         $message->from('support@aistore2030.com','Payment Disputed');
         
      });


              
              
         $data = array('name'=>$recipient_user_email,'message1'=>
         'Payment Dispute by ' . $GLOBALS['user_email'],'amount1'=>$recipient_user_amount,'currency'=>$recipient_user_currency,'description'=>$recipient_user_description);
        
        // $GLOBALS['name']=$request->name;
   
      Mail::send('mail1', $data, function($message) {
         $message->to($GLOBALS['email'], 'Payment Disputed')->subject
            ('Payment Disputed');
         $message->from('support@aistore2030.com','Payment Disputed');
         
      });
     $ar['Error']=false; 
    
    $ar['Message']=  "Request processed successfully.";
  }
  else
  {
         $ar['Error']=true; 
    
    $ar['Message']=  "Unable to processed request.";
      
  }
  
  
  
    return response()->json($ar);
    
}
 

 
public function delete_payment(Request $request)
{ 
    
    $ar=array();
      
      
       $user = Auth::user();
    
    $user_id=$user->id;
  
     
      
  $data=DB::table('safe_payment')->where('user_id',$user->id)->where('status',"Pending")->where('id',$request->id)->first()  ;
  
  
 $recipient_user =User::where('id',$data->recipient_user_email)->first() ;
               
  if( $recipient_user== null)
  {
      
      
      DB::table('safe_payment')->where('id',$data->id)->delete();
      
      
      
      $pc=new Paymentcls();
      
      
  $pc->credit_user(  $user,$data->amount,$data->coin, $data->description  );
   $data = array('name'=>'Payment Cancel to  ' .$data->recipient_user_email);
         $GLOBALS['email']=$data->recipient_user_email;
        // $GLOBALS['name']=$request->name;
   
      Mail::send('mail', $data, function($message) {
         $message->to($GLOBALS['email'], 'Payment Cancel')->subject
            ('Payment Cancel');
         $message->from('support@aistore2030.com','Payment Cancel');
         
      });
  
             
  
  
       $ar['Error']=false; 
    
    $ar['Message']=  "Request processed successfully.";
  }
  else
  {
         $ar['Error']=true; 
    
    $ar['Message']=  "Unable to processed request.";
      
  }
  
  
  
    return response()->json($ar);
    
}
 
public function release_payment(Request $request)
{ 
    
    $ar=array();
      
      
       $user = Auth::user();
    
    $user_id=$user->id;
      $user_email=$user->email;
      $pc=new Paymentcls();
      
      
 // $data=DB::table('safe_payment')->where('user_id',$user->id)->where('status',"Pending")->where('id',$request->id)->first()  ;
  
  
       
  $q="SELECT  * from safe_payment where user_id=$user->id and ( status='Pending' or status='Dispute' ) and id= $request->id ";
  
  
  
  
  $res = DB::select($q) ;
  
  
  $data= $res[0];
  
// var_dump(  $data); var_dump($data->amount);
  
  
 // var_dump( $request->amount);
  
 $recipient_user =User::where('email',$data->recipient_user_email)->first() ;
               
  if( $recipient_user== null)
  {
       $ar['Error']=true; 
    
    $ar['Message']=  "User is not active so it can be released.";
      
  }
  
  
else  if($data->amount < $request->amount )
  {
       $ar['Error']=true; 
    
    $ar['Message']=  "You do not have sufficient amount.";
      
  }
  
  
else  if($data->amount == $request->amount )
  {
      
      
  
   
      
$affected = DB::table('safe_payment')
              ->where('user_id',  $user_id)
              ->where('id', $request->id) 
              ->update(['status' => "Released"]);
              
              
 
      
  $pc->credit_user( $recipient_user,$data->amount,$data->coin, $data->description  );
  
  
  
     $data = array('name'=>$user_email,'message1'=>'Payment Dispute to ' .$recipient_user_email,'amount1'=>$recipient_user_amount,'currency'=>$recipient_user_currency,'description'=>$recipient_user_description);
         
              $GLOBALS['email']= $recipient_user_email;
        $GLOBALS['user_email']=$user_email;
   
      Mail::send('mail1', $data, function($message) {
         $message->to($GLOBALS['user_email'], 'Payment Disputed')->subject
            ('Payment Disputed');
         $message->from('support@aistore2030.com','Payment Disputed');
         
      });


              
              
        
  
             
    $ar['Error']=false; 
    
    $ar['Message']=  "Released successfully"; 
         
      
  }
  else
  {
       $remain_amount=(double)$data->amount - (double)$request->amount;
       
       
      $trid = DB::table('safe_payment')->insertGetId(
    [ 
    'amount' => $remain_amount, 
     
      'coin' =>$data->coin ,  
      'user_id' =>$data->user_id,
    'description' => $data->description ,
     'recipient_user_email' =>$data->recipient_user_email ,
     'status'=>"Pending"
   ]
);


   $trid = DB::table('safe_payment')->insertGetId(
    [ 
    'amount' => $request->amount, 
    
         'coin' =>$data->coin ,  
      'user_id' =>$data->user_id,
    'description' => $data->description ,
     'recipient_user_email' =>$data->recipient_user_email ,
     'status'=>"Released"
   ]
);
       
       
     $affected = DB::table('safe_payment')
              ->where('user_id',  $user_id)
              ->where('id', $request->id) 
              ->update(['status' => "Closed"]);  
              
       
   
      
  $pc->credit_user( $recipient_user,$this->request['amount'],$data->coin, $data->description  );
  
  $recipient_user_email= $data->recipient_user_email;
  $recipient_user_amount= $data->amount;
   $recipient_user_currency= $data->coin;
    $recipient_user_description= $data->description;
  
    
              $data = array('name'=>$user_email,'message1'=>'Payment Released to ' .$recipient_user_email,'amount1'=>$recipient_user_amount,'currency'=>$recipient_user_currency,'description'=>$recipient_user_description);
         
              $GLOBALS['email']= $recipient_user_email;
        $GLOBALS['user_email']=$user_email;
   
      Mail::send('mail1', $data, function($message) {
         $message->to($GLOBALS['user_email'], 'Payment Released')->subject
            ('Payment Released');
         $message->from('support@aistore2030.com','Payment Released');
         
      });


              
              
         $data = array('name'=>$recipient_user_email,'message1'=>
         'Payment Released by ' . $GLOBALS['user_email'],'amount1'=>$recipient_user_amount,'currency'=>$recipient_user_currency,'description'=>$recipient_user_description);
        
        // $GLOBALS['name']=$request->name;
   
      Mail::send('mail1', $data, function($message) {
         $message->to($GLOBALS['email'], 'Payment Released')->subject
            ('Payment Released');
         $message->from('support@aistore2030.com','Payment Released');
         
      });
      
      
    $ar['Error']=false; 
    
    $ar['Message']=  "Released successfully";
    
    
  }
  
  
   
    
    return response()->json($ar);
    
    
    
    
}
      
  
       public function payment_list(Request $request)
{ 
    
       $user = Auth::user();
    
    $user_id=$user->id;
    
    
     
    
     //$q="SELECT * FROM `safe_payment` LEFT JOIN  ( SELECT id uid  , email from  users ) t  ON  recipient_user_email=email   where   user_id =  $user_id or  recipient_user_email =  '$user->email'   ";
     
     
  $q="SELECT  * ,    IF(user_id= $user_id and !ISNULL(uid) , 'true' , 'false' )  rs  from (SELECT * FROM `safe_payment` LEFT JOIN  ( SELECT id uid  , email , first_name,last_name,mobile from  users ) t  ON  recipient_user_email=email     where   user_id =  $user_id or  recipient_user_email =  '$user->email' )t   ";
  
  
  
  
  $data = DB::select($q) ;
  
   
         
  
  
        $ar=array();
    $ar['Error']=false; 
     $ar['result']=$data; 
     $ar['qr']=$q; 
   
    
    return response()->json($ar);
    
    
    
}
   
  
   
    public function add_payment()
{ 
    
    
       $user = Auth::user();
    
    $user_id=$user->id;
    $user_email=$user->email;
  
    $pc=new Paymentcls();
    $coin="INR";
    
    

    $ar=array();
    
  if(  !$pc->debit_user( $user,$this->request['amount'],
  $this->request['coin'], $this->request['description'] ))
  
  
  {
 
 $recipient_user_email =$this->request['recipient_user_email'] ;
               
     
  $recipient_user_amount= $this->request['amount'];
   $recipient_user_currency= $this->request['coin'];;
    $recipient_user_description=  $this->request['description'];
     
      $trid = DB::table('safe_payment')->insertGetId(
    [ 
    'amount' => $this->request['amount'], 
    'recipient_user_email' => $recipient_user_email  , 
     
      'coin' => $this->request['coin'],  
      'user_id' =>    $user_id,
    'description' => $this->request['description'],
     'status'=>"Pending"
   ]
);
 

$data = array('name'=>$user_email,'message1'=>'Add Payment to ' .$recipient_user_email,'amount1'=>$recipient_user_amount,'currency'=>$recipient_user_currency,'description'=>$recipient_user_description);
         
              $GLOBALS['email']=$this->request['recipient_user_email'];
        $GLOBALS['user_email']=$user_email;
   
      Mail::send('mail1', $data, function($message) {
         $message->to($GLOBALS['user_email'], 'Safe Payment')->subject
            ('Added Safe Payment');
         $message->from('support@aistore2030.com','Safe Payment');
         
      });



 $data = array('name'=>$recipient_user_email,'message1'=>
        'Add Payment by ' . $GLOBALS['user_email'],'amount1'=>$recipient_user_amount,'currency'=>$recipient_user_currency,'description'=>$recipient_user_description);
         
    
   
      Mail::send('mail1', $data, function($message) {
         $message->to($GLOBALS['email'], 'Safe Payment')->subject
            ('Added Safe Payment');
         $message->from('support@aistore2030.com','Safe Payment');
         
      });


    $ar['Error']=false; 
    
    $ar['Message']=  "Add payment successfully";
     return response()->json($ar);
    
  }
//   else
  
//   {
//       $ar['Error']=true; 
    
//     $ar['Message']=  "Failure";
      
//   }
    
   
    
    
    
    
}




 public function safe_payment_list(Request $request)
{ 
    
       $user = Auth::user();
    
 
    
     
    $q="SELECT * FROM `safe_payment`    where status = 'Pending' and  recipient_user_email =  '$user->email'    ";
     
 
  
  
  $data = DB::select($q) ;
  
   
         
  
  
        $ar=array();
    $ar['Error']=false; 
     $ar['result']=$data; 
  
   
    
    return response()->json($ar);
    
    
    
}
   


 public function escrow_list(Request $request)
{ 
    
       $user = Auth::user();
    
 
    
     
    $q="SELECT * FROM `safe_payment`    where  status <> 'Closed' and  recipient_user_email =  '$user->email'    ";
     
 
  
  
  $data = DB::select($q) ;
  
   
         
  
  
        $ar=array();
    $ar['Error']=false; 
     $ar['result']=$data; 
  
   
    
    return response()->json($ar);
    
    
    
}
   
  
  


}