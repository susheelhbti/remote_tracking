<?php


namespace App\Http\Controllers;

 
use App\Page;
use App;
use View;
use MetaTag; 
use Mail;
use App\ChargeCommision;
use App\Income;
use App\MemberExtra;
use App\Deposit;
use App\Gateway;
use App\Lib\GoogleAuthenticator;
use App\Transaction;
use App\User;
use Config;
use App\Coins;
use App\Screens;
use App\Exchange_deposit;

use App\System_Settings;

use App\Employee; 
use Illuminate\Support\Facades\DB;

 
use App\Http\Controllers\Controller;


use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Intervention\Image\Facades\Image;


use App\Notifications\Login;

 
class EmpCtrl extends Controller
{
    private $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
        
    
            
            
    }
 
 

         public function addemployee(Request $request)
{ 
    
    
        $ar=array();
        $user = new Employee;
         $user->first_name =$request->first_name;
         $user->last_name =$request->last_name;
        $user->email = $request->email;
          $user->parent_id  = Auth::user()->id;
        
        $user->user_key = rand(1000,9999).'-'.rand(1000,9999) .'-'.rand(1000,9999).'-'.rand(1000,9999) ;

 


        $user->save();
        $ar['message']="Employee created Successfully!.";
      
         $ar['Error']=false;
         return response()->json($ar);
         
         
       
    }
 
 
         public function listemployees()
{ 
     
   $user_id=Auth::user()->id;
     
   $q1="SELECT * FROM ( SELECT * FROM invitations WHERE parent_id= $user_id  and status=1 ) t LEFT join users u on u.email =t.email   ";
           
           
             $data=  DB::select(DB::raw($q1)) ;
        
        
  return response()->json($data );
    
}

 
   
   
   
   
         public function getInvitations()
{ 
    $roll=Auth::user()->roll;
 
    if(  $roll==10){
     
      
   $data=  DB::table('employee')
        ->leftJoin('users', 'users.id', '=', 'employee.parent_id')->select('users.first_name', 'users.last_name', 'users.email', 
        'users.created_at','employee.user_key','employee.status') 
        ->get();
        
        
 $data=DB::table('employee')->orderBy('id', 'desc')->take(50)->get()  ;
    }
    else
    {
        
           
    $data=  DB::table('employee')
        ->leftJoin('users', 'users.id', '=', 'employee.parent_id')->select('users.first_name', 
        'users.last_name', 'users.email', 'users.created_at', 
        'employee.user_key','employee.id','employee.status')->where('employee.email',Auth::user()->email)
        ->get();
        
        
      //  $data=DB::table('employee')->where('email',Auth::user()->email)->orderBy('id', 'desc')->take(50)->get()  ;
    }
    
    
  return response()->json($data );
    
}







    public function deleteInvitation(Request $request)
{  $roll=Auth::user()->roll;
 
    if(  $roll==10){
     
    
    $affectedRows = Employee::where('id', $request['id'])->where('status', 0)->delete();
    
    }
    else
    {
        $affectedRows = Employee::where('id', $request['id'])->where('status', 0)->where('parent_id', Auth::user()->id)->delete();
     
    }
    
  
       $ar=array();
       
         if($affectedRows>0)
         {
        $ar['message']="Deleted rows .".$affectedRows;
      
         $ar['Error']=false;
         }
         else
         {
              $ar['message']="Deleted rows .".$affectedRows;
      
         $ar['Error']=true;
             
         }
         
         return response()->json($ar);
         
}






        public function changeStatus(Request $request)

    {

        $employee = Employee::find($request['id']);

        $employee->status =  $employee->status==1?0:1;
    

        $employee->save();

   $ar=array();
         
        $ar['message']="Status updated Successfully!.";
      
         $ar['Error']=false;
         return response()->json($ar);
         

    }
    
    
    
    
         public function screenemailme()
{ 
    
    // the login here is not correct
    
    // a screen can be seen only by two person and 1 admin
    
    // so we need to following steps
    
    // verirfy authorization for the request
    
    // fetch screen by screen id 
    
    // and then email 
    
    
        $employee = Employee::find($request['id']);
        
        
     
   $user_id=Auth::user()->id;
   $user_email=Auth::user()->email;
     
   $q1="SELECT * FROM `users` u ,invitations i WHERE u.email=i.email and u.email in (SELECT email FROM `invitations` WHERE parent_id=$user_id )  ";
           
           
             $data=  DB::select(DB::raw($q1)) ;
             
        $data1 = array('name'=>'Screenshots to '. $user_email);
        
        
         $GLOBALS['email']= $user_email;
        // $GLOBALS['name']=$request->name;
   
      Mail::send(['text'=>'mail'], $data, function($message) {
         $message->to('noureenahsan91@gmail.com', 'Screenshots')->subject
            ('Screenshots');
         $message->from($GLOBALS['email'],'Screenshots');
         
      });
        
    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Request submitted successfully";
    
    return response()->json($ar);
    
}
     
 
        public function verify_user_key(Request $request)

    {
        
        
        
     //   $q="SELECT users.id ,users.email, users.first_name , users.last_name FROM `users` , invitations WHERE invitations.email=users.email and invitations.user_key='".$request['user_key']."'";
        
        
    // $get=  DB::select(DB::raw( $q)->first());
  
   
  $get=     DB::table('users')
            ->join('invitations', 'users.email', '=', 'invitations.email')->where('user_key', $request['user_key'])
              ->select("users.email",  "first_name" , "last_name")
              ->first();  

     $ar=array();
              
        if ($get === null) {
  
        $ar['Message']="Invalid data!.";
         
     
         $ar['Error']= true ;
       
}
 
else
{
     
         
        $ar['Message']="Status updated Successfully!.";
         
       $ar['first_name']=  "". $get->first_name ;
       $ar['last_name']= "".  $get->last_name ;
       $ar['email']=   $get->email ;
         $ar['Error']= false ;
        
}

  return response()->json($ar);

         

    }
 


public function workupdate()
{ 
     $event=$this->request['event'] ;
     
     
     $user_key=$this->request['user_key'] ;
     
     
     $user_id=3;//$this->request['user_key'] ;
     
      if($event=='working')
  {
  $trid = DB::table('working_workupdate')->insertGetId(
    [ 'user_key' => $user_key ,'start' => 'working','user_id' =>$user_id  ]
);

} 
   
else  if($event=='start')
  {
  $trid = DB::table('workupdate')->insertGetId(
    [ 'user_key' => $user_key ,'start' => 'start','user_id' =>$user_id  ]
);

}
else
//   ->whereNull("stop")
{
 
     $affected = DB::table("workupdate")
              ->where("user_key", $user_key)
              ->where("start", "start")
           
              ->update([ "stop"=>"stop" ]);
              
}             
              

    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Request submitted successfully";
    
    return response()->json($ar);
    
}


 
 
public function markcloseworkinghours()
{  echo "ss";
    
    
    $data=DB::table('workupdate')->where("start", "start")->whereNull('stop')->get()  ;
    
    var_dump($data);
    foreach($data as $d)
    {
        
        echo $d->user_key;
        
         $data_n=DB::table('working_workupdate')->where("user_key",$d->user_key)->whereRaw('created_at >  now() - interval 5 minute')->get()  ;
         
         
         if(count($data_n)==0)
         {
             
     $affected = DB::table("workupdate")
              ->where("user_key",$d->user_key)
              ->where("start", "start")
           
              ->update([ "stop"=>"stop" ]);
         }
         
         
          print_r($data_n);
         
    }
    
    // print_r($data);
     
}



public function workinghours()
{  
    
    
    
     $user_key=$this->request['user_key'] ;
     
  

     $get=  DB::select(DB::raw("SELECT DATE(`created_at`) start_date ,SEC_TO_TIME( sum( UNIX_TIMESTAMP( updated_at)- UNIX_TIMESTAMP(created_at))
                     ) duration   FROM `workupdate` WHERE user_key= '$user_key' GROUP by start_date "));
  
    return response()->json($get );
     
}   






public function informscreen()
{  
    
    
     $screenurl=$this->request['screenurl'] ;
    
    
     $user_key=$this->request['user_key'] ;
     
 $trid = DB::table('screens')->insertGetId(
    [ 'user_key' => $user_key ,'screenurl' =>$screenurl   ]
);
 
    
    
      $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Request submitted successfully";
    
    return response()->json($ar);
     
} 
 
public function screens()
{  
    $ar=array();
    
     $dt=$this->request['dt'] ;
    
    
     $user_key=$this->request['user_key'] ;
    
     $result=  DB::select(DB::raw("SELECT *  FROM `screens` WHERE date(dt)='".$dt."' and user_key='".$user_key."'  ")) ;
  
 // $get = $result->toArray();
  
  
  $arr= array();
  
  
  $arry= array();
  
  
    $user = Auth::user();
    
    $user_email=$user->email;
  foreach($result as $g)
  { 
       $arr['id']=$g->id;
       $arr['user_key']=$g->user_key;
       $arr['created_at']=$g->created_at;
       $arr['dt']=$g->dt;
       $arr['screenb64']=$g->screenurl;
       
       
       $arr['screenurl']="https://t1.aistore2030.com/screen_load/".$g->screenurl;
   
        
      
    
      array_push($arry,$arr);
     
        
      
  }
  
  
  $ar['result']=$arry;
    $ar['status']=200;
    return response()->json($ar );
    
    
     
     
}   


public function emailme()
{  
    $ar=array();
    $user = Auth::user();
    
    $user_email=$user->email;
   $user_id=$user->id;
     
 $data=DB::table('screens')->where('id',$this->request['id'])->first()  ;
      $screen_url=$data->screenurl;
      $user_key=$data->user_key;
       $dt=$data->dt;
       $created_at=$data->created_at;
    

      $data1=DB::table('invitations')->where('user_key',$user_key)->first()  ;
       $email=$data1->email;
      
      $data2=DB::table('users')->where('email', $email)->first()  ;
       $full_name=$data2->first_name . '  '. $data2->last_name;
       $mobile=$data2->mobile;
       $address=$data2->address1;
       
        $data = array('name'=>$user_email,'message1'=>$user_id. ' to Screenshot  ' .$this->request['id'] ,'id'=>$this->request['id'],'user_key'=>$user_key,'dt'=>$dt,'date'=>$created_at,'email'=>$email,'full_name'=>$full_name,'mobile'=>$mobile,'address'=>$address);
        
        
         $GLOBALS['email']= $user_email;
         $GLOBALS['url']= $screen_url;
   
      Mail::send('mail2', $data, function($message) {
         $message->to('noureenahsan91@gmail.com', 'Screenshots')->subject
            ('Screenshots');
             $message->attach("https://t1.aistore2030.com/screen_load/".$GLOBALS['url']);
         $message->from('support@aistore2030.com','Screenshots');
        
         
      });
        
      
  
  
  
  $ar['result']="successfully";
    $ar['status']=200;
    return response()->json($ar);
    
    
     
     
}   


public function deleteme()
{  
    $ar=array();
    
    // $id=$this->request['id'] ;
    
    
     //$user_key=$this->request['user_key'] ;
     
        $task = Screens::find($this->request['id']);

       $task->delete();


        $ar['message']=" Deleted successfully.";
              
              
        $ar['Error']=false;

        return response()->json($ar);

    
    
     
     
}   



public function random_screens()
{  
    $ar=array();
    
    
    
    
     $user_key=$this->request['user_key'] ;
    
     $result=  DB::select(DB::raw("SELECT *  FROM `screens` WHERE     user_key='".$user_key."' and   DATE(`created_at`) = CURDATE() ORDER BY RAND() limit 7   ")) ;
  
 // $get = $result->toArray();
  
  
  $arr= array();
  
  
  $arry= array();
  
  
  
  foreach($result as $g)
  { 
       $arr['id']=$g->id;
       $arr['user_key']=$g->user_key;
       $arr['created_at']=$g->created_at;
       $arr['dt']=$g->dt;
       $arr['screenb64']=$g->screenurl;
       
       
       $arr['screenurl']="https://t1.aistore2030.com/screen_load/".$g->screenurl;
    
    
      array_push($arry,$arr);
      
  }
  
  
  $ar['result']=$arry;
    $ar['status']=200;
    return response()->json($ar );
    
    
     
     
}  



public function random_screens_today()
{  
    $ar=array();
    
    
    
    
     $user_key=$this->request['user_key'] ;
    
     $result=  DB::select(DB::raw("SELECT *  FROM `screens` WHERE     user_key='".$user_key."' and   DATE(`created_at`) = CURDATE() ORDER BY RAND() limit 7   ")) ;
  
 // $get = $result->toArray();
  
  
  $arr= array();
  
  
  $arry= array();
  
  
  
  foreach($result as $g)
  { 
       $arr['id']=$g->id;
       $arr['user_key']=$g->user_key;
       $arr['created_at']=$g->created_at;
       $arr['dt']=$g->dt;
       $arr['screenb64']=$g->screenurl;
       
       
       $arr['screenurl']="https://t1.aistore2030.com/screen_load/".$g->screenurl;
    
    
      array_push($arry,$arr);
      
  }
  
  
  $ar['result']=$arry;
    $ar['status']=200;
    return response()->json($ar );
    
    
     
     
}   









public function team_random_screens_today()
{  
    $ar=array();
       $user_id= Auth::user()->id;
     
    $q="SELECT *  FROM `screens` WHERE     user_key in (SELECT user_key   FROM `invitations` WHERE parent_id=   $user_id )  and   DATE(`created_at`) = CURDATE() ORDER BY RAND() limit 3   ";
    
    
    $q="SELECT * FROM `screens` , (SELECT users.first_name , users.last_name , users.email , users.id,invitations.user_key FROM `users` , invitations WHERE users.email=invitations.email ) t WHERE t.user_key=screens.user_key and screens.user_key in (SELECT user_key FROM `invitations` WHERE parent_id=  $user_id  ) and DATE(`created_at`) = CURDATE() ORDER BY RAND() limit 9 ";
    
    
    
        $result=  DB::select(DB::raw($q)) ;
         
         
         
  
  $arr= array();
  
  
  $arry= array();
  
  
  
  foreach($result as $g)
  { 
       $arr['id']=$g->id;
        $arr['user_key']=$g->user_key;
       
       $arr['first_name']=$g->first_name;
       
       $arr['last_name']=$g->last_name;
       $arr['email']=$g->email;
       
       
       $arr['created_at']=$g->created_at;
       $arr['dt']=$g->dt;
       $arr['screenb64']=$g->screenurl;
       
       
       $arr['screenurl']="https://t1.aistore2030.com/screen_load/".$g->screenurl;
    
    
      array_push($arry,$arr);
      
  }
  
  
  $ar['result']=$arry;
  $ar['message']= $q;
    $ar['status']=200;
    return response()->json($ar );
    
    
     
     
} 





public function team_work_report()
{ 
       $user_id=Auth::user()->id;
     
    $q=" SELECT  *   FROM `invitations` WHERE parent_id=   $user_id    ";
    
    
         $result=  DB::select(DB::raw($q)) ;
         
             $row=array();
         
         foreach($result as $r)
         {
           
            $r1=array();
 
     $q1="    SELECT DATE(`created_at`) start_date ,SEC_TO_TIME( sum( UNIX_TIMESTAMP( updated_at)- UNIX_TIMESTAMP(created_at))  ) duration   FROM `workupdate` WHERE user_key= '$r->user_key' GROUP by start_date";
     
    
        $res=  DB::select(DB::raw($q1)) ;
     
      $r1['res']= $res;
      
         $r1['user_key']=$r->user_key;
         $r1['email']=$r->email;
         
         array_push($row,$r1);
         }
 
// print_r($row);
 
      $ar=array();
     
  $ar['result']=$row;
 // $ar['message']= $q;
    $ar['status']=200;
    return response()->json($ar );
} 













    public function KYCUsers()
{ 
    
 //$user_id= Auth::user()->id;
 $data=DB::table('users')->where('status',1)->orderBy('id', 'desc')->get()  ;
  return response()->json($data );
    
}



    public function NonKYCUsers()
{ 
    
 //$user_id= Auth::user()->id;
 $data=DB::table('users')->where('status',0)->orderBy('id', 'desc')->get()  ;
  return response()->json($data );
    
}







    public function DeleteUsersAccountRequest()
{ 
    
 //$user_id= Auth::user()->id;
 $data=DB::table('users')->where('account_status',1)->orderBy('id', 'desc')->get()  ;
  return response()->json($data );
    
}

         public function Ledgetmembership()
{ 
    
    //$user_id= Auth::user()->id;
 $data=DB::table('membership')->orderBy('id', 'asc')->get()  ;
      
  return response()->json($data );
    
}


public function postdeposits(Request $r)
{
 
   $deposit=   "";
       $user_id= Auth::user()->id;
     
    
    
     $deposit=  $this->getBtcAddress( );
   
    $id = DB::table('exchange_deposit')->insertGetId(
    [ 'user_id' => $user_id ,'coin' => $r->coin ,'deposit_address' => $deposit ,'amount' => $r->amount ]
);
 
  
 
   
  $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Request submitted successfully";
    
    return response()->json($ar);
    
   
} 

public function receive_payment(Request $r)
{
 $ar=array();
 
 
   $deposit=   "";
       $user_id= Auth::user()->id;
     
     
    
    $deposit=  $this->getBtcAddress( );
   
    $ar['address']= $deposit;
    $ar['coin']="Bitcoin";
 
 
  
   
   
   
   $r=array();
   $r['status']=200;
   $r['result']=$ar;
  
    return response()->json($r);
  
   
} 

 

 
 



public function send_payment()
{ 
       $user = Auth::user();
    
    $user_id=$user->id;
  
    
      $trid = DB::table('system_transactions')->insertGetId(
    [ 'user_id' => $user_id ,'coin' => $this->request['coin']  ,'cr' => 0 ,'dr' =>  $this->request['amount_coin']  ,'status' =>"Success" ,'description' =>"Widthdraw Request ". $this->request['to']   ]
);

     
            
     $id = DB::table('exchange_widthdraw')->insertGetId(
    [ 'user_id' => $user_id ,'coin' => $this->request['coin'] ,'amount' => $this->request['amount_coin'],'widthdraw_address' =>  $this->request['to'] ]
);

 



    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Request submitted successfully";
    
    return response()->json($ar);
    
    
    
    
}



public function add_plan()
{ 
       $user = Auth::user();
    
    $user_id=$user->id;
  
    
      $trid = DB::table('membership')->insertGetId(
    [ 'user_id' => $user_id ,'plan' => $this->request['name'] ,
    'row1' =>  $this->request['row1'] ,
    'row2' =>  $this->request['row2'] ,
    'row3' =>  $this->request['row3'] ,
    'row4' =>  $this->request['row4'],
        'row5' =>  $this->request['row5'],
            'row6' =>  $this->request['row6'],
                'row7' =>  $this->request['row7'],
    'price' =>  $this->request['price']]
);

  


    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Plan submitted successfully";
    
    return response()->json($ar);
    
    
    
    
}


 
 
 
 
public function selfscreens()
{  
    $ar=array();
       $email= Auth::user()->email;
      
    
  $q="SELECT *  FROM screens WHERE   user_key in (SELECT user_key   FROM `invitations` WHERE email='$email')  ORDER BY RAND() limit 9    ";
    
    
        $result=  DB::select( $q)  ;
         
         
         
  
  $arr= array();
  
  
  $arry= array();
  
  
  
  foreach($result as $g)
  { 
       $arr['id']=$g->id;
        $arr['user_key']=$g->user_key;
       
      // $arr['first_name']=$g->first_name;
       
       //$arr['last_name']=$g->last_name;
  ////     $arr['email']=$g->email;
       
       
       $arr['created_at']=$g->created_at;
       $arr['dt']=$g->dt;
       $arr['screenb64']=$g->screenurl;
       
       
       $arr['screenurl']="https://t1.aistore2030.com/screen_load/".$g->screenurl;
    
    
      array_push($arry,$arr);
      
  }
  
  
  $ar['result']=$arry;
  $ar['message']= $q;
    $ar['status']=200;
    return response()->json($ar );
    
    
     
     
} 



public function self_work_report()
{ 
    
            $r1=array();
 
     $q1="    SELECT  DATE(`created_at`) start_date ,SEC_TO_TIME( sum( UNIX_TIMESTAMP( updated_at)- UNIX_TIMESTAMP(created_at))  ) duration ,user_key  FROM `workupdate` WHERE user_key in ( SELECT user_key  FROM `invitations` WHERE email='".Auth::user()->email ."')  GROUP by start_date ,user_key";
     
    
        $res=  DB::select(DB::raw($q1)) ;
     
     
      $ar=array();
     
  $ar['result']=$res ;
  $ar['message']= $q1;
    $ar['status']=200;
    return response()->json($ar );
} 



          
}