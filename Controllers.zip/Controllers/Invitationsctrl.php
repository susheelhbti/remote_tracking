<?php


namespace App\Http\Controllers;

 
use App\Page;
use App;
use View;
use MetaTag; 

use App\ChargeCommision;
use App\Income;
use App\MemberExtra;
use App\Deposit;
use App\Gateway;
use App\Lib\GoogleAuthenticator;
use App\Transaction;
use App\User;
use Config;
use App\Coins;
use Mail;
use App\Exchange_deposit;

use App\System_Settings;

use App\Invitation; 


use Illuminate\Support\Facades\DB;

 
use App\Http\Controllers\Controller;


use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Intervention\Image\Facades\Image;


use App\Notifications\Login;

 
class Invitationsctrl extends Controller
{
    private $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
        
    
            
            
    }
 
 

         public function create(Request $request)
{ 
    
    
        $ar=array();
        $in = new Invitation;
        
        $user = Auth::user();
        $user_email=$user->email;
        
         $in->email = $request->email;
         
         
          $in->parent_id  = Auth::user()->id;
          $user = Auth::user();
         $user_email=$user->email;
         $user_name=$user->first_name;
          $GLOBALS['email']=$user_email;
         $GLOBALS['invite_email']=$request->email;
         
          
         $data = array('name'=>$GLOBALS['email'],'message1'=>'You have been invited by ' .$user_name . ' to work together please visit the site and approve and get auth code and start please visit support page for any kind of help');
         
        
   
      Mail::send('mail', $data, function($message) {
         $message->to($GLOBALS['email'], 'Invite')->subject
            ('Invited by  '. $GLOBALS['invite_email']);
         $message->from('support@aistore2030.com',$GLOBALS['invite_email']);
         
      });
      
    
 
          $data = array('name'=>$GLOBALS['invite_email'],'message1'=>'You have been invited by ' .$user_name . ' to work together please visit the site and approve and get auth code and start please visit support page for any kind of help');
         
   
      Mail::send('mail', $data, function($message) {
         $message->to($GLOBALS['invite_email'], 'Invite')->subject
            ('Invited to  '. $GLOBALS['email']);
         $message->from('support@aistore2030.com',$GLOBALS['email']);
         
      });
      
      
         $in->save();
         
         
        $ar['message']="Invitation send Successfully!.";
      
         $ar['Error']=false;
         return response()->json($ar);
         
         
       
    }
 
 
         public function sendbyyou()
{ 
     
 $data=DB::table('invitations')->where('parent_id',Auth::user()->id)->orderBy('id', 'desc')->take(50)->get()  ;
      
  return response()->json($data );
    
}

 
   
   
         public function receivebyyou()
{ 
      
      
       $data=  DB::table('invitations')
        ->leftJoin('users', 'users.id', '=', 'invitations.parent_id')->select('users.first_name', 'users.last_name', 'users.email', 'users.created_at','invitations.user_key','invitations.auth_key','invitations.id','invitations.status')
        ->where('invitations.email',Auth::user()->email)
        ->get();
        
         
      
  return response()->json($data );
    
}
   
   
         public function getInvitations()
{ 
    $roll=Auth::user()->roll;
 
    if(  $roll==10){
     
      
   $data=  DB::table('employee')
        ->leftJoin('users', 'users.id', '=', 'employee.parent_id')->select('users.first_name', 'users.last_name', 'users.email', 'users.created_at','employee.auth_key','employee.status') 
        ->get();
        
        
 $data=DB::table('employee')->orderBy('id', 'desc')->take(50)->get()  ;
    }
    else
    {
        
           
    $data=  DB::table('employee')
        ->leftJoin('users', 'users.id', '=', 'employee.parent_id')->select('users.first_name', 'users.last_name', 'users.email', 'users.created_at','employee.auth_key','employee.id','employee.status')->where('employee.email',Auth::user()->email)
        ->get();
        
        
      //  $data=DB::table('employee')->where('email',Auth::user()->email)->orderBy('id', 'desc')->take(50)->get()  ;
    }
    
    
  return response()->json($data );
    
}







    public function deleteInvitation(Request $request)
{
    
    $roll=Auth::user()->roll;
 
    if(  $roll==10){
     
     
    $affectedRows = Invitation::where('id', $request['id'])->where('status', 0)->delete();
    
    }
    else
    {
        $affectedRows = Invitation::where('id', $request['id'])->where('status', 0)->where('parent_id', Auth::user()->id)->delete();
     
    }
    
  
       $ar=array();
       
         if($affectedRows>0)
         {
        $ar['message']="Deleted Successfully." ;
      
         $ar['Error']=false;
         }
         else
         {
              $ar['message']="Failure." ;
      
         $ar['Error']=true;
             
         }
         
         return response()->json($ar);
         
}






        public function changeStatus(Request $request)

    {

        $in = Invitation::find($request['id']);

        $in->status =  1;
    
  $in->auth_key = '2020-'.rand(1000,9999) .'-'.rand(1000,9999).'-'.rand(1000,9999) ;



  
  $in->user_key = $in->auth_key  ;



        $in->save();

   $ar=array();
         
        $ar['message']="Status updated Successfully!.";
      
         $ar['Error']=false;
         return response()->json($ar);
         

    }
    
    
    
    
    
    

    public function KYCUsers()
{ 
    
 //$user_id= Auth::user()->id;
 $data=DB::table('users')->where('status',1)->orderBy('id', 'desc')->get()  ;
  return response()->json($data );
    
}



    public function NonKYCUsers()
{ 
    
 //$user_id= Auth::user()->id;
 $data=DB::table('users')->where('status',0)->orderBy('id', 'desc')->get()  ;
  return response()->json($data );
    
}







    public function DeleteUsersAccountRequest()
{ 
    
 //$user_id= Auth::user()->id;
 $data=DB::table('users')->where('account_status',1)->orderBy('id', 'desc')->get()  ;
  return response()->json($data );
    
}

         public function Ledgetmembership()
{ 
    
    //$user_id= Auth::user()->id;
 $data=DB::table('membership')->orderBy('id', 'asc')->get()  ;
      
  return response()->json($data );
    
}


public function postdeposits(Request $r)
{
 
   $deposit=   "";
       $user_id= Auth::user()->id;
     
    
    
     $deposit=  $this->getBtcAddress( );
   
    $id = DB::table('exchange_deposit')->insertGetId(
    [ 'user_id' => $user_id ,'coin' => $r->coin ,'deposit_address' => $deposit ,'amount' => $r->amount ]
);
 
  
 
   
  $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Request submitted successfully";
    
    return response()->json($ar);
    
   
} 

public function receive_payment(Request $r)
{
 $ar=array();
 
 
   $deposit=   "";
       $user_id= Auth::user()->id;
     
     
    
    $deposit=  $this->getBtcAddress( );
   
    $ar['address']= $deposit;
    $ar['coin']="Bitcoin";
 
 
  
   
   
   
   $r=array();
   $r['status']=200;
   $r['result']=$ar;
  
    return response()->json($r);
  
   
} 

 

 
 



public function send_payment()
{ 
    


    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Request submitted successfully";
    
    return response()->json($ar);
    
    
    
    
}



public function add_plan()
{ 
       $user = Auth::user();
    
    $user_id=$user->id;
  
    
      $trid = DB::table('membership')->insertGetId(
    [ 'user_id' => $user_id ,'plan' => $this->request['name'] ,
    'row1' =>  $this->request['row1'] ,
    'row2' =>  $this->request['row2'] ,
    'row3' =>  $this->request['row3'] ,
    'row4' =>  $this->request['row4'],
        'row5' =>  $this->request['row5'],
            'row6' =>  $this->request['row6'],
                'row7' =>  $this->request['row7'],
    'price' =>  $this->request['price']]
);

  


    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Plan submitted successfully";
    
    return response()->json($ar);
    
    
    
    
}


 
          
}