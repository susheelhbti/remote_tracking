<?php


namespace App\Http\Controllers;

 
use App\Page;
use App;
use View;
use MetaTag; 

use App\ChargeCommision;
use App\Income;
use App\MemberExtra;
use App\Deposit;
use App\Gateway;
use App\Lib\GoogleAuthenticator;
use App\Transaction;
use App\User;
use Config;
use App\Coins;

use App\Exchange_deposit;

use App\System_Settings;

use App\Employee; 
use Illuminate\Support\Facades\DB;

 
use App\Http\Controllers\Controller;


use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Intervention\Image\Facades\Image;


use App\Notifications\Login;

 
class ProjectCtrl extends Controller
{
    private $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
        
    
            
            
    }
  


 
public function release_payment(Request $request)
{  $ar=array();
      
      
       $user = Auth::user();
    
    $user_id=$user->id;
  
      $pc=new Paymentcls();
      
      
  $data=DB::table('payment')->where('user_id',$user->id)->where('status',"Pending")->where('id',$request->id)->first()  ;
  
  
  
  
 $recipient_user =User::where('status',1)->where('id',$data->recipient_user_id)->first() ;
               
  
  if($data->amount < $request->amount )
  {
       $ar['Error']=true; 
    
    $ar['Message']=  "You do not have sufficient amount.";
      
  }
  
  
else  if($data->amount == $request->amount )
  {
      
      
  
   
      
$affected = DB::table('payment')
              ->where('user_id',  $user_id)
              ->where('id', $request->id) 
              ->update(['status' => "Released"]);
              
              
 
      
  $pc->credit_user( $recipient_user,$this->request['amount'],$data->coin, $data->description  );
  
  
  
  
             
    $ar['Error']=false; 
    
    $ar['Message']=  "Released successfully"; 
         
      
  }
  else
  {
       $remain_amount=(double)$data->amount - (double)$request->amount;
       
       
      $trid = DB::table('payment')->insertGetId(
    [ 
    'amount' => $remain_amount, 
      'project_id' =>$data->project_id ,    
      'coin' =>$data->coin ,  
      'user_id' =>$data->user_id,
    'description' => $data->description ,
     'recipient_user_id' =>$data->recipient_user_id ,
     'status'=>"Pending"
   ]
);


   $trid = DB::table('payment')->insertGetId(
    [ 
    'amount' => $request->amount, 
      'project_id' =>$data->project_id ,  
         'coin' =>$data->coin ,  
      'user_id' =>$data->user_id,
    'description' => $data->description ,
     'recipient_user_id' =>$data->recipient_user_id ,
     'status'=>"Released"
   ]
);
       
       
     $affected = DB::table('payment')
              ->where('user_id',  $user_id)
              ->where('id', $request->id) 
              ->update(['status' => "Closed"]);  
              
       
   
      
  $pc->credit_user( $recipient_user,$this->request['amount'],$data->coin, $data->description  );
  
  
            
      
      
    $ar['Error']=false; 
    
    $ar['Message']=  "Released successfully";
    
    
  }
  
  
   
    
    return response()->json($ar);
    
    
    
    
}
      
  
       public function payment_list(Request $request)
{ 
    
       $user = Auth::user();
    
    $user_id=$user->id;
    
    
    
       $q=" select *  from payment where ( user_id =  $user_id or  recipient_user_id = $user_id ) and  project_id=$request->id ";
    
    
     
  
  
  $data = DB::select($q) ;
  
   
            
            
             
  
  
        $ar=array();
    $ar['Error']=false; 
     $ar['result']=$data; 
     $ar['qr']=$q; 
   
    
    return response()->json($ar);
    
    
    
}
   
  
   
    public function add_payment()
{ 
    
    
       $user = Auth::user();
    
    $user_id=$user->id;
  
    $pc=new Paymentcls();
    $coin="INR";
    
    

    $ar=array();
    
  if(  !$pc->debit_user( $user,$this->request['amount'],
  $this->request['coin'], $this->request['description'] ))
  
  
  {
    
    
     
  
 $recipient_user =User::where('status',1)->where('email', $this->request['recipient_user_email'])->first() ;
               
     
     
      $trid = DB::table('payment')->insertGetId(
    [ 
    'amount' => $this->request['amount'], 
    'recipient_user_id' => $recipient_user->id , 
      'project_id' => $this->request['project_id'], 
      'coin' => $this->request['coin'],  
      'user_id' =>    $user_id,
    'description' => $this->request['description'],
     'status'=>"Pending"
   ]
);
 




    $ar['Error']=false; 
    
    $ar['Message']=  "Add payment successfully";
    
  }
  else
  
  {
      $ar['Error']=true; 
    
    $ar['Message']=  "Failure";
      
  }
    
    return response()->json($ar);
    
    
    
    
}


 

public function add_task()
{ 
       $user = Auth::user();
    
    $user_id=$user->id;
  
    
      $trid = DB::table('task')->insertGetId(
    [ 
    'task_name' => $this->request['task_name'],
       'project_id' => $this->request['project_id'],
       'user_id'=> $user_id
   ]
);

  


    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Add Task successfully";
    
    return response()->json($ar);
    
    
    
    
}
      
      
public function add_member()
{ 
       $user = Auth::user();
    
    $user_id=$user->id;
  
    
   $ar=array();
   
   if($user->email==$this->request['email'])
   {
         $ar['Error']=true; 
    
    $ar['Message']=  "Some Error" ;
         return response()->json($ar);
    
   }

  
 try {
     
     
           $trid = DB::table('project_members')->insertGetId(
    [ 
    'email' => $this->request['email'],
       'project_id' => $this->request['project_id'],
       'user_id'=> $user_id,  'status'=>0
   ]
);

 
    $ar['Error']=false; 
    
    $ar['Message']=  "Add member successfully";
    
 
    
    
    }  
catch (\Exception $e)
{ $error_code = $e->errorInfo[1];
        $ar['Error']=true; 
    
    $ar['Message']=  "Some Error" ;
    }
     
       return response()->json($ar);
    
}
      
      
      
      
public function add_file(Request $request)
{ 
       $user = Auth::user();
    
    $user_id=$user->id;
    
    
      

        $fileName = "hjhjhj";  

   file_put_contents(public_path('uploads')."sfsdfds", file_get_contents( $request->file));
   
   

    //    $request->file->move(public_path('uploads'), $fileName);

 
            
            
            
    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=   $request->file;
    
    return response()->json($ar);
    
    
    
    
}


      
public function removemembers(Request $request)
{ 
       $user = Auth::user();
    
    $user_id=$user->id;
    
    
    
 $da=   DB::table('project_members')
    ->where('project_id',$request->project_id)
    ->where('email',$request->email)
    ->where('user_id',$user_id)
    ->where('status', 0)->delete();
    
    
    
     
    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Request submitted successfully".$da;
    
    return response()->json($ar);
    
    
    
    
}
      
      
      
      
       public function task_list(Request $request)
{ 
    
  $data=DB::table('task')->where('project_id',$request->id)->orderBy('id', 'desc')->get()  ;
      
      
  return response()->json($data );
    
}
   
   
      
       public function project_members(Request $request)
{ 
    $user = Auth::user();
    
    
  $data=DB::table('project_members')
  ->where('project_id',$request->id)
  ->where('email','<>', $user->email)
  ->where('user_id', $user->id)->orderBy('id', 'desc')->get()  ;
      
      
  return response()->json($data );
    
}
   
   
   
   
   
   
      public function task_by_id(Request $request)
{ 
    
    
        
    
    //$user_id= Auth::user()->id;
 $data=DB::table('task')->where('id',$request->id)->orderBy('id', 'desc')->get()  ;
      
  return response()->json($data );
    
}   

public function task_update()
    {
        
        $ar=array();
  
        $ar['Error']=true;
 
        
           
       $ar['message']="Successfully updated the task.";
              
              
             $ar['Error']=false;
             
 return response()->json($ar);
    }
    
    
    public function add_project()
{ 
       $user = Auth::user();
    
    $user_id=$user->id;
  
    
      $trid = DB::table('project')->insertGetId(
    [ 
    'project_name' => $this->request['project_name'],
      'user_id' =>$user_id,
    'status'=>0
   ]
);

      $trid = DB::table('project_members')->insertGetId(
    [ 
    'project_id' =>$trid,
      'email' =>$user->email,
      'user_id' =>$user_id,
        
    'status'=>1
   ]
);





    $ar=array();
    $ar['Error']=false; 
    
    $ar['Message']=  "Add Project successfully";
    
    return response()->json($ar);
    
    
    
    
}
       public function project_list()
{ 
    
      $user = Auth::user() ;
    
    $user_id= $user->id;
    $email= $user->email;
    
     
    $q=" select distinct project_id  from project_members where user_id=  $user_id or  email ='$email'   ";
    
   
  
  
  $results = DB::select($q) ;
  
  $n=array();
 
  $i=0;
     
 foreach($results  as $cl1)
 { 
    
    $n[$i]=$cl1->project_id;
    $i=$i+1;
}


   $pid=  implode("," ,$n);
     
     
     
     $q1=" select *  from project where  id  in (   $pid )  ";
    
    
     
  
  
  $data = DB::select($q1) ;
  
   
        $ar=array();
    $ar['Error']=false; 
    
 
    
    
     $ar['result']=$data; 
   
    
    return response()->json($ar);
    
     
    
}




   public function projectbyid(Request $request)
{ 
    
      $user = Auth::user() ;
    
    $user_id= $user->id;
    $email= $user->email;
    
     
    $q=" select distinct project_id  from project_members where (  user_id=  $user_id or  email ='$email' )   and project_id= ". $request->id  ;
    
    
  
  $results = DB::select($q) ;
  
  $res  =   $results[0] ;
    
   $q=" select *  from project  where  id=  $res->project_id ";
    
    
   $projects = DB::select($q) ;
   $project= $projects[0];
  
  $form_display=array();
  
   $form_display['id']=$project->id;
   
   $form_display['project_name']=$project->project_name;
   
   $form_display['user_id']= $user_id;
   
      $form_display['status']=$project->status;
  if($project->user_id== $user_id)
  {
      
      $form_display['edit_product']=true;
      
      // count members and then if member count is more then 1 then only shows form otherwise not
      
      
      
    $q=" select   project_id  from project_members where  project_id= ". $project->id  ;
      $rs = DB::select($q) ;
      $form_display['project_members']= count($rs);

  if( count($rs) > 1)
 
   $form_display['add_payment_form']=true;
   
   else
  $form_display['add_payment_form']=false;
      
      $form_display['release_payment_form'] =true;
      $form_display['cancel_payment_form'] =true;
      $form_display['invite_member_form']=true;
      $form_display['delete_member']=true;



      $form_display['refund_payment'] =false;
      $form_display['delete_myself']=false;
  }
  else
  {
         
      
            $form_display['edit_product'] =false;
            
            
      $form_display['add_payment_form'] =false;
      
      
      $form_display['release_payment_form']  =false;
      $form_display['cancel_payment_form'] =false;
      $form_display['invite_member_form'] =false;
      $form_display['delete_member'] =false;



      $form_display['refund_payment'] =true;
      $form_display['delete_myself']=true;
 
  
  }
  
      $ar=array();
    $ar['Error']=false; 
    
 
    
    
 //  $ar['qr']=  $q; 
    
   //$ar['result']=  $results; 
   $ar['result']=$form_display; 
   
    
    return response()->json($ar);
  
  
  
  
  
}


}